<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $motherName = $_POST['motherName'] ?? '';
    $email = $_POST['email'] ?? '';
    $service = $_POST['service'] ?? '';

    $mail = new PHPMailer(true);

    try {
        // SMTP configuration
        $mail->isSMTP();
        $mail->Host = 'smtp.yourdomain.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'support@readsigns.site';
        $mail->Password = 'yourpassword';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // From & To
        $mail->setFrom('support@readsigns.site', 'Spiritual Consultation Site');
        $mail->addAddress('support@readsigns.site');

        // Email content
        $mail->isHTML(true);
        $mail->Subject = 'New Spiritual Consultation Request';
        $mail->Body = "<h3>New Consultation Request</h3>
            <p><strong>Name:</strong> {$name}</p>
            <p><strong>Mother's Name:</strong> {$motherName}</p>
            <p><strong>Email:</strong> {$email}</p>
            <p><strong>Service:</strong> {$service}</p>";

        if (isset($_FILES['giftCard']) && $_FILES['giftCard']['error'] === UPLOAD_ERR_OK) {
            $mail->addAttachment($_FILES['giftCard']['tmp_name'], $_FILES['giftCard']['name']);
        }

        $mail->send();
        echo json_encode(['success' => true, 'message' => 'Consultation details sent successfully.']);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Mailer Error: ' . $mail->ErrorInfo]);
    }
}
?>